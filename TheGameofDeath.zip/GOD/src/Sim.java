import java.awt.Color;
import java.awt.Graphics;
import java.awt.GraphicsConfiguration;
import java.awt.HeadlessException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;


public class Sim extends JPanel {
	static String virus;
	//size to print the humans
	private static int size = 10;
	private int DAY = 0;
	private int LOOP = 0;
	JFrame frame = new JFrame();
	StatPanel SP = new StatPanel();
	
	List<Human> Healthy = new CopyOnWriteArrayList<Human>();
	List<infectedHuman> Infected = new CopyOnWriteArrayList<infectedHuman>();
	List<Deceased> Dead = new CopyOnWriteArrayList<Deceased>();
	
	//initialise a virus
	Virus v;
	
	//viruses: "Ebola","Influenza","Smallpox"
	
	Random R = new Random();

	public Sim(String virus){
		//get the virus selected
		this.virus = virus;
		
		//set size
		setSize(600,600);
		
		//create 1000 humans within the area
		for(int i=0; i<1000; i++){
			Human h = new Human(i, R.nextInt(600), R.nextInt(600));
			Healthy.add(h);
		}
		
		//get a random number between 0-1000 to infect a random person
		int I = R.nextInt(1001);
		
		//create a new virus depending on the virus selected.
		if(virus.equals("Ebola")){
			//create a new Ebola virus
			v = new Virus("Ebola", 0);
		}
		else if(virus.equals("Influenza")){
			//create a new Flu virus
			v = new Virus("Influenza", 2);
		}
		else if(virus.equals("Smallpox")){
			//create a new Smallpox virus
			v = new Virus("Smallpox", 12);
		}
		else if(virus.equals("Typhoid")){
			//create a typhoid virus
			v = new Virus(virus, 30);
		}
		
		//infect the random human with the virus....
		Human h = Healthy.get(I);
		System.out.println("Human "+I+ " Has been infected");
		v.infect(Healthy, Infected, h);	
	}
	
	public void paint(Graphics g){
		//print the background white
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 600, 600);
		
		//now print humans in green (-5 taken to print the circle around the coords)
		for(Human H : Healthy){
			g.setColor(Color.GREEN);
			g.fillOval(H.getxCord()-5, H.getyCord()-5, size, size);
		}
		
		//print infected humans, check whether they are carriers or not
		for(infectedHuman IH : Infected){
			if(IH.checkCarrier() == true){
				g.setColor(Color.RED);
				g.fillOval(IH.getxCord()-5, IH.getyCord()-5, size, size);
			}
			else {
				g.setColor(Color.LIGHT_GRAY);
				g.fillOval(IH.getxCord()-5, IH.getyCord()-5, size, size);
			}
		}
		
		//print deceased
		for(Deceased D : Dead){
			g.setColor(Color.BLACK);
			g.fillOval(D.getxCord(), D.getyCord(), size, size);
		}
		
		simulate();	
	}

	private void simulate() {
		//increment the loop... every 5 loops = 1 day
		LOOP++;
		
		//move healthy, infected and carriers
		for(Human H : Healthy){
			H.move();	
		}
		
		//move all the infected people
		for(infectedHuman IH : Infected){
			IH.move();
		}
		
		//check for spread in infectedLoop
		synchronized(Infected){
			Iterator<infectedHuman> IT = Infected.iterator();
			while(IT.hasNext()){
				infectedHuman IH = IT.next();
				IH.infect(Healthy, Infected, v);
				int D = IH.getDaysLeft();
				if(D == 0){
					//remove infected human from infected, create deceased instance and add to dead list.
					Infected.remove(IH);
					Deceased DH = new Deceased(IH.getId(), IH.getxCord(), IH.getyCord());
					Dead.add(DH);
					
				}
			}
		}
		
		//get the stats for the stat screen and create it.
		String health, inf, dead, day, carr;
		int Carriers = 0;
		health = ""+Healthy.size();
		inf = ""+Infected.size();
		
		//check amount of carriers
		for(infectedHuman IH : Infected){
			if(IH.isCarrier() == true){
				Carriers++;
			}
		}
		carr = ""+Carriers;
		dead = ""+Dead.size();
		day = ""+DAY;
		
		if(LOOP == 1){
			frame.setSize(200, 400);
			frame.setResizable(false);
			frame.add(SP);
			frame.setVisible(true);			
		}
		SP.UpdateStrings(health, inf, carr, dead, day);
				
		//add a day counter
		if((LOOP == 0) || (LOOP % 10 == 0)){
			DAY++;
			//remove 1 day off the infected humans lives
			for(infectedHuman IH : Infected){
				IH.degen();
			}
			System.out.println("----- NEW DAY -----");
			System.out.println("Healthy Population: "+Healthy.size());
			System.out.println("Infected Population: "+Infected.size());
			System.out.println("Carrier Population: "+Carriers);
			System.out.println("Dead Population: "+Dead.size());
			System.out.println("Day: "+DAY);			
		}
		
		try{
			Thread.sleep(200);
			repaint();
		} catch (InterruptedException e) {
			System.out.println(e);
		}

	}

}





















