import java.util.Random;


public class Human {
	
	//Different states:
	//H - Healthy - (GREEN PEOPLE)
	//C - Carrier - (PURPLE PEOPLE)
	//I - Infected - (ORANGE PEOPLE)
	//D - Deceased - (RED PEOPLE)

	int id, xCord, yCord;
	char state;
	int health = 100;
	
	public Human(int ID, int xCord, int yCord) {
		id = ID;
		this.xCord = xCord;
		this.yCord = yCord;
		this.state = state;
	}
	
	//getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getxCord() {
		return xCord;
	}

	public void setxCord(int xCord) {
		this.xCord = xCord;
	}

	public int getyCord() {
		return yCord;
	}

	public void setyCord(int yCord) {
		this.yCord = yCord;
	}

	
	public void move(){
		int x = getxCord();
		int y = getyCord();
		int min = 1;
		int max = 4;
		int dist;
		Random r = new Random();
		dist = r.nextInt(10)+ 1;
		int move = r.nextInt(max - min + 1) + min;
		//check if the human is going out of screen
			if(x <= 10){ move = 2; dist = 10;
		}
			else if(y <= 10){ move = 3; dist = 10;
		}
			else if(x >= 590){ move = 4; dist = 10;
		}
			else if(y >= 590){ move = 1; dist = 10;
		}
			
		switch(move){
		case 1:
			//move north
			y = y - dist;
			setyCord(y);
			break;
		
		case 2:
			//move east
			x = x + dist;
			setxCord(x);
			break;
			
		case 3:
			//move south
			y = y + dist;
			setyCord(y);
			break;
			
		case 4:
			//move west
			x = x - dist;
			setxCord(x);						
			break;
		}
	}
	
	public int Rand(int x){
		Random r = new Random();
		return r.nextInt(x);
	}

}
