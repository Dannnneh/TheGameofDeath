import java.awt.Graphics;
import java.awt.LayoutManager;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class Title extends JPanel {

	public static BufferedImage image;
	
	public Title(){
		super();
		try{
			image = ImageIO.read(this.getClass().getResource("TitleScreen.png"));
		} catch (IOException e){
			System.out.println(e);
		}
	}
	
	public void paintComponent(Graphics g){
		g.drawImage(image, 0, 0, this);
		repaint();
	}

}
