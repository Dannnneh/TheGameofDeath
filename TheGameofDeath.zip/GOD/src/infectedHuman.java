
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;


public class infectedHuman extends Human {
	private boolean carrier = false;
	int ID, xCord, yCord, DaysLeft;

	public infectedHuman(int ID, int xCord, int yCord, String Vname, int DaysLeft, boolean Carrier) {
		super(ID, xCord, yCord);
		this.ID = ID;
		this.xCord = xCord;
		this.yCord = yCord;
		this.DaysLeft = DaysLeft;
		this.carrier = Carrier;
	}
	
	public int getDaysLeft() {
		return DaysLeft;
	}
	
	public boolean isCarrier() {
		return carrier;
	}

	public void setCarrier(boolean carrier) {
		this.carrier = carrier;
	}

	public boolean checkCarrier(){
		return carrier;
		
	}
	
	public void infect(List<Human> healthy, List<infectedHuman> infected, Virus v) {
		//get coords for the infected human and virus name, get daysLeft and determine if carrier
		int infX, infY;
		infX = getxCord();
		infY = getyCord();
		
		//check if any humans are near the infected human
		synchronized(healthy){
			Iterator<Human> IT = healthy.iterator();
			while(IT.hasNext()){
				Human h = IT.next();
				int Hx = h.getxCord();
				int Hy = h.getyCord();
				//If a healthy person gets too close, infect them...
				if(((Hx - infX) * (Hx - infX)) + ((Hy - infY) * (Hy - infY)) < (10*10)){
					healthy.remove(h);
					//create a new infectedHuman and add to infected list
					infectedHuman IH = new infectedHuman(h.getId(), 
					h.getxCord(), h.getyCord(), v.getName(), v.daysLeft(), v.makeCarier());
					
					infected.add(IH);
				}
			}
		}
	}
	
	//take 1 day off the lifespan.
	public void degen() {
		DaysLeft --;
	}
}
