import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class TheGameOfDeath extends JFrame {
	
	private JComboBox Cbox;
	private JLabel title = new JLabel("The Game of Death");
	private JLabel choose = new JLabel("Select a virus");
	private JButton start = new JButton("Start");
	private static String [] VirusMenu = {"Ebola","Influenza","Smallpox", "Typhoid"};
	private JPanel panel = new JPanel();
	private JPanel boxPanel = new JPanel();
	
	public static ArrayList<Human> Humans = new ArrayList<Human>();
	public static ArrayList<Virus> Viruses = new ArrayList<Virus>();
	
	public TheGameOfDeath() {
		super("The Game of Death");
		setSize(520, 330);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
			
		
		//create a new box, add a JLabel, ComboBox and JButton.
		Box box = Box.createHorizontalBox();
		box.setPreferredSize(new Dimension(500, 30));
		box.add(new JLabel("Select a virus: "));
		box.add(Box.createHorizontalGlue());
		
		//create a new JComboBox with the virus values and add it to box.
		Cbox = new JComboBox(VirusMenu);
		Cbox.setPreferredSize(new Dimension(30, 200));
		box.add(Cbox);
		box.add(Box.createHorizontalGlue());
		 
		//add JButton.
		box.add(start);
		//box.add(Box.createHorizontalStrut(20));
		
		//add actionListener to the JButton
		start.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				//get value from the dropdown box.
				String virus = (String) Cbox.getSelectedItem();
				
				Sim b = new Sim(virus);
				JFrame Sim = new JFrame(""+virus);
				Sim.add(b);
				b.setIgnoreRepaint(true);
				Sim.setSize(600,600);
				Sim.setResizable(false);
				Sim.setVisible(true);
			}
			
		});
		
		boxPanel.add(box);
		//add the JPanel and box to the JFrame
		add(new Title(), BorderLayout.CENTER);
		add(boxPanel, BorderLayout.SOUTH);
	}
	
	public static void main(String [] args){
		TheGameOfDeath TGOD = new TheGameOfDeath();
		TGOD.setResizable(false);
		TGOD.setVisible(true);
	}
	
	public static int rand(){
		Random r = new Random();
		return r.nextInt(600);
	}
}
