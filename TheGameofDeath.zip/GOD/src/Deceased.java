
public class Deceased extends Human{
	private static int ID;
	private static int xCord;
	private static int yCord;

	public Deceased(int ID, int xCord, int yCord){
		super(ID, xCord, yCord);
		this.ID = ID;
		this.xCord = xCord;
		this.yCord = yCord;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public int getxCord() {
		return xCord;
	}

	public void setxCord(int xCord) {
		this.xCord = xCord;
	}

	public int getyCord() {
		return yCord;
	}

	public void setyCord(int yCord) {
		this.yCord = yCord;
	}

}
