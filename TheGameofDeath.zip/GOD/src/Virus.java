import java.util.List;
import java.util.Random;


public class Virus {
	private static String Name;
	private static int incPeriod;
	Random r = new Random();

	public Virus(String Name, int incPeriod) {
		this.Name = Name;
		this.incPeriod = incPeriod;
	}

	public boolean makeCarier() {
		//carriers will depend on virus's...
		//some viruses have little chance of making carriers... (Typhoid)
		if(Name.equals("Typhoid")){
			//300 to 1 chance of becoming a carrier
			Random r = new Random();
			if(r.nextInt(301) == r.nextInt(301)){
				return true;
			}
		}
		return false;
	}

	public int daysLeft() {
		//returns the amount of days that the infected human will live....
		if(getName().equals("Ebola")){
			//if Ebola the incPeriod is 2-21 days
			//create a random number from 0-19 and add 2 to make it random between 2-21 days
			int EbolaInc = r.nextInt(20);
			EbolaInc = EbolaInc + 2;
			return EbolaInc;			
		}
		if(getName().equals("Thyphoid")){
			//typhoid has an incubation period of 6-30 days
			//create a random number from 0-24, then add 6 to make a range of 6-30
			int ThyphInc = r.nextInt(25);
			ThyphInc = ThyphInc + 6;
			return ThyphInc;			
		}
		if(getName().equals("Smallpox")){
			//smallpox can range from 7 - 17 days
			int smallInc = r.nextInt(11);
			smallInc = smallInc + 7;
			return smallInc;
		}
		else{
			return incPeriod;
		}
	}

	public String getName() {
		return Name;
	}
	
	public void infect(List<Human> healthy, List<infectedHuman> infected, Human h){
		//infects one random person within the boundaries of the map
		synchronized(healthy){
			healthy.remove(h);
			infectedHuman IH = new infectedHuman(h.getId(), 
					h.getxCord(), h.getyCord(), getName(), daysLeft(), makeCarier());
			infected.add(IH);
			
		}
	}

}
