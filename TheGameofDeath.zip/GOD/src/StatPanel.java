import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;


public class StatPanel extends JPanel{
	
	String Healthy = "Healthy population: ";
	String Infected = "Infected population: ";
	String Carriers = "Carrier population: ";
	String Dead = "Number of Dead: ";
	String Day = "Day: ";
	
	public void UpdateStrings(String H, String I, String C, String D, String d){
		Healthy = "Healthy population: "+H;
		Infected = "Infected population: "+I;
		Carriers = "Carrier population: "+C;
		Dead = "Number of Dead: "+D;
		Day = "Day: "+d;
		
		repaint();
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		g.drawString(Healthy, 10, 10);
		g.drawString(Infected, 10, 20);
		g.drawString(Carriers, 10, 30);
		g.drawString(Dead, 10, 40);
		g.drawString(Day, 10, 50);
		
	}
	
}